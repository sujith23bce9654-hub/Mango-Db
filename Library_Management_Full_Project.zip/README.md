# Library Management System
Features:
- Books CRUD
- Students CRUD
- Issue/Return CRUD
- Search APIs
- MongoDB Aggregation examples
- Sample Data
Run:
npm install
node server.js
