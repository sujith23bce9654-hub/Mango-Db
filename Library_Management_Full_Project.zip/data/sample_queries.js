
// CRUD Examples
db.books.find()
db.students.find()
db.issues.find()

db.books.aggregate([{$group:{_id:"$category",count:{$sum:1}}}])
